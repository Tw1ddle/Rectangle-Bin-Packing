## 1.0.1
* Make private members public/readonly for convenience

## 1.0.0
* Initial release